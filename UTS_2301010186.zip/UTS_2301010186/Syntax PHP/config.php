<?php

$server = "localhost";
$user = "root";
$password = "";
$dbname = "lagu_hits";

$db = mysqli_connect($server, $user, $password, $dbname);

if (!$db) {
	die("Gagal terhubung dengan database: " . mysqli_connect_error());
}

function getAllData($db)
{
    $sql = "SELECT * FROM lagu_hits";
    $result = mysqli_query($db, $sql);

    $lagu = [];

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $lagu[] = $row;
        }
    }

    return $lagu;
}
function findLaguHitsByID($db, $id) 
{
    $sql = "SELECT * FROM lagu_hits WHERE id = $id LIMIT 1";
    $result = mysqli_query($db, $sql);


    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            return $row;
        }
    }

    return null;
}

function laguhitsBaru($db, $lagu)
{
    $sql = "INSERT INTO lagu_hits
    (judul, deskripsi, likes, genre, penyanyi, created_at, updated_at)
    VALUES (
        {$lagu['judul']}, 
        '{$lagu['deskripsi']}', 
        '{$lagu['likes']}', 
        '{$lagu['genre']}', 
        '{$lagu['penyanyi']}', 
        NOW(), 
        NOW()
    );";

    if (mysqli_query($db, $sql)) {
        return mysqli_insert_id($db);
    }

    return null;
}


