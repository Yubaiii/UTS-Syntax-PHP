<?php
require_once "config.php";

$id = $_GET['id'];

$d = findLaguHitsByID($db, $id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Informasi Lagu</title>
    <style>
        body {
            background-image: url(https://www.shutterstock.com/shutterstock/videos/1059635129/thumb/1.jpg?ip=x480);
            font-family: Arial, sans-serif;
            filter: opacity(96%);
        }

        h1 {
            width: 40%;
            margin: 0 auto;
            padding: 15px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
            
            text-align: center;
            font-size: 40px;
            line-height: 1.6;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
        }

        a {
            font-size: 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <h1>Detail Informasi Lagu Anda</h1>
    
    <br>

    <nav class="container">
    <a href="/list-lagu.php">Kembali ke Daftar lagu</a>

    <br>
    <br>

    <p>Judul: <?= $d['judul'] ?></p>
    <p>Deskripsi: <?= $d['deskripsi'] ?></p>
    <p>Likes: <?= $d['likes'] ?></p>
    <p>Genre: <?= $d['genre'] ?></p>
    <p>Penyanyi: <?= $d['penyanyi'] ?></p>
    <p>Created At: <?= $d['created_at'] ?></p>
    <p>Updated At: <?= $d['updated_at'] ?></p>
    </nav>
</body>


</html>

<?php
mysqli_close($db);
?>