<?php 
require_once "config.php"; 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Lagu Anda</title>
    <style>
        table,
        th,
        td {
            border: 1px solid;
            padding: 10px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        body {
            background-image: url(https://www.shutterstock.com/shutterstock/videos/1059635129/thumb/1.jpg?ip=x480);
            font-family: Arial, sans-serif;
            filter: opacity(96%);
        }

        h3 {
            width: 40%;
            margin: 0 auto;
            padding: 15px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
            
            text-align: center;
            font-size: 40px;
            line-height: 1.6;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
        }

        a {
            text-align: left;
            font-size: 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <header>
        <h3>Daftar Lagu Anda</h3>
    </header>

    <br>
    <br>

    <nav class="container">
        <a href="index.php">Kembali ke Home</a>
        <br>
        <br>
        <button><a href="tambah-lagu.php">Tambah Lagu Baru</a></button>

    <br>
    <br>

    <?php if(isset($_GET['status'])): ?>
            <p>
                <center>
                <?php
                    if($_GET['status'] == 'sukses'){
                        echo "Penambahan lagu anda berhasil!";
                    } else {
                        echo "Penambahan lagu gagal!";
                    }
                ?>
                </center>
            </p>
    <?php endif; ?>

    <table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Likes</th>
            <th>Genre</th>
            <th>Penyanyi</th>
            <th>Tindakan</th>
        </tr>
    </thead>
    <tbody>

        <?php
        $sql = "SELECT * FROM lagu_hits";
        $query = mysqli_query($db, $sql);

        while($lagu = mysqli_fetch_array($query)){
            echo "<tr>";

            echo "<td><center>".$lagu['id']."</center></td>";
            echo "<td>".$lagu['judul']."</td>";
            echo "<td>".$lagu['deskripsi']."</td>";
            echo "<td>".$lagu['likes']."</td>";
            echo "<td>".$lagu['genre']."</td>";
            echo "<td>".$lagu['penyanyi']."</td>";

            echo "<td><center>";
            echo "<a href='penambahan-detail.php?id=".$lagu['id']."'>Detail</a> | ";
            echo "<a href='edit-lagu.php?id=".$lagu['id']."'>Edit</a> | ";
            echo "<a href='hapus-lagu.php?id=".$lagu['id']."'>Hapus</a>";
            echo "</td>";

            echo "</center></tr>";
        }
        ?>

    </tbody>
    </table>
    
    <p>Total: <?php echo mysqli_num_rows($query) ?></p>

    </nav>

    </body>
</html>
