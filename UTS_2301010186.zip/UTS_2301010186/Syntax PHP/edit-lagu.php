<?php

require_once "config.php";

// kalau tidak ada id di query string
if( !isset($_GET['id']) ){
    header('Location: list-lagu.php');
}

//ambil id dari query string
$id = $_GET['id'];

// buat query untuk ambil data dari database
$sql = "SELECT * FROM lagu_hits WHERE id=$id";
$query = mysqli_query($db, $sql);
$lagu = mysqli_fetch_assoc($query);

// jika data yang di-edit tidak ditemukan
if( mysqli_num_rows($query) < 1 ){
    die("data tidak ditemukan...");
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Lagu</title>
    <style>
        body {
            background-image: url(https://www.shutterstock.com/shutterstock/videos/1059635129/thumb/1.jpg?ip=x480);
            filter:blur(90%);
            font-family: Arial, sans-serif;
            background-color: white;
        }

        h3 {
            width: 40%;
            margin: 0 auto;
            padding: 15px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
            
            text-align: center;
            font-size: 40px;
            line-height: 1.6;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            font-size: 18px;
        }

        input {
            font-size: 16px;
        }

        textarea {
            font-size: 16px;
        }

        select {
            font-size: 16px;
        }

    </style>
</head>

<body>
    <header>
        <h3>Edit Lagu Anda</h3>
    </header>

    <br>

    <form action="proses-edit.php" method="POST">

        <fieldset class="container">

            <input type="hidden" name="id" value="<?php echo $lagu['id'] ?>" />

        <p>
            <label for="judul">Judul: </label>
            <input type="text" name="judul" placeholder="Judul Lagu" value="<?php echo $lagu['judul'] ?>" />
        </p>
        <p>
            <label for="deskripsi">Deskripsi: </label>
            <textarea name="deskripsi"><?php echo $lagu['deskripsi'] ?></textarea>
        </p>
        <p>
            <label for="likes">Likes: </label>
            <?php $likes = $lagu['likes']; ?>
            <label><input type="radio" name="likes" value="Good" <?php echo ($likes == 'good') ? "checked": "" ?>> Good</label>
            <label><input type="radio" name="likes" value="Bad" <?php echo ($likes == 'bad') ? "checked": "" ?>> Bad</label>
        </p>
        <p>
            <label for="genre">Genre: </label>
            <?php $genre = $lagu['genre']; ?>
            <select name="genre">
                <option <?php echo ($genre == 'pop') ? "selected": "" ?>>Pop</option>
                <option <?php echo ($genre == 'rnb') ? "selected": "" ?>>RnB</option>
                <option <?php echo ($genre == 'rock') ? "selected": "" ?>>Rock</option>
                <option <?php echo ($genre == 'romance') ? "selected": "" ?>>Romance</option>
                <option <?php echo ($genre == 'indie') ? "selected": "" ?>>Indie</option>
                <option <?php echo ($genre == 'kpop') ? "selected": "" ?>>Kpop</option>
            </select>
        </p>
        <p> 
            <label for="penyanyi">Penyanyi: </label>
            <input type="text" name="penyanyi" placeholder="Nama Penyanyi" value="<?php echo $lagu['penyanyi'] ?>" />
        </p>
        <p>
            <input type="submit" value="Simpan" name="simpan" />
        </p>

        </fieldset>


    </form>

    </body>
</html>
