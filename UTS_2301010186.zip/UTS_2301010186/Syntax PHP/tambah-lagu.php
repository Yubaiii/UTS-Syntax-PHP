<!DOCTYPE html>
<html>
<head>
    <title>Tambah Lagu</title>
    <style>
        body {
            background-image: url(https://www.shutterstock.com/shutterstock/videos/1059635129/thumb/1.jpg?ip=x480);
            filter:blur(90%);
            font-family: Arial, sans-serif;
            background-color: white;
        }

        h3 {
            width: 40%;
            margin: 0 auto;
            padding: 15px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
            
            text-align: center;
            font-size: 40px;
            line-height: 1.6;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            font-size: 18px;
        }

        input {
            font-size: 16px;
        }

        textarea {
            font-size: 16px;
        }

        select {
            font-size: 16px;
        }

    </style>
</head>

<body>
    <header>
        <h3>Tambah Lagu Baru Anda</h3>
    </header>

    <br>

    <form action="proses-penambahan.php" method="POST">

        <fieldset class="container">

        <p>
            <label for="judul">Judul: </label>
            <input type="text" name="judul" placeholder="Judul Lagu" />
        </p>
        <p>
            <label for="deskripsi">Deskripsi: </label>
            <textarea name="deskripsi"></textarea>
        </p>
        <p>
            <label for="likes">Likes: </label>
            <label><input type="radio" name="likes" value="Good"> Good</label>
            <label><input type="radio" name="likes" value="Bad"> Bad</label>
        </p>
        <p>
            <label for="genre">Genre: </label>
            <select name="genre">
                <option>Pop</option>
                <option>RnB</option>
                <option>Rock</option>
                <option>Romance</option>
                <option>Indie</option>
                <option>Kpop</option>
            </select>
        </p>
        <p>
            <label for="penyanyi">Penyanyi: </label>
            <input type="text" name="penyanyi" placeholder="Nama Penyanyi" />
        </p>
        <p>
            <input type="submit" value="Simpan" name="simpan" />
        </p>

        </fieldset>

    </form>

    </body>
</html>
