<?php
require_once "config.php";
session_start();

$n = laguhitsBaru($db, $_POST);

mysqli_close($db);

if (is_null($n)) {
    $_SESSION['BERHASIL_TAMBAH_LAGU'] = "Gagal Menambah Data";
} else {
    $_SESSION['BERHASIL_TAMBAH_LAGU'] = "Berhasil Menambah Data Lagu";
}

header("Location: /list-lagu.php");
die();
