<?php

require_once "config.php";

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['simpan'])){

    // ambil data dari formulir
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $likes = $_POST['likes'];
    $genre = $_POST['genre'];
    $penyanyi = $_POST['penyanyi'];

    // buat query
    $sql = "INSERT INTO lagu_hits 
    (judul, deskripsi, likes, genre, penyanyi, created_at, updated_at) 
    VALUE (
        '$judul',
        '$deskripsi',
        '$likes',
        '$genre',
        '$penyanyi',
        NOW(),
        NOW()
    );";
    
    $query = mysqli_query($db, $sql);

    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: list-lagu.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: tambah-lagu.php?status=gagal');
    }


} else {
    die("Akses dilarang...");
}


