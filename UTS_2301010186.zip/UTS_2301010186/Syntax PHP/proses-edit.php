<?php

require_once "config.php";

// cek apakah tombol simpan sudah diklik atau blum?
if(isset($_POST['simpan'])){

    // ambil data dari formulir
    $id = $_POST['id'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $likes = $_POST['likes'];
    $genre = $_POST['genre'];
    $penyanyi = $_POST['penyanyi'];

    // buat query update
    $sql = "UPDATE lagu_hits SET judul='$judul', deskripsi='$deskripsi', likes='$likes', genre='$genre', penyanyi='$penyanyi' WHERE id=$id";
    $query = mysqli_query($db, $sql);

    // apakah query update berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman list-siswa.php
        header('Location: list-lagu.php');
    } else {
        // kalau gagal tampilkan pesan
        die("Gagal menyimpan perubahan...");
    }


} else {
    die("Akses dilarang...");
}

