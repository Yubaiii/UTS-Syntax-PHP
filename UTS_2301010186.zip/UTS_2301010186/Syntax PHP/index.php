<!DOCTYPE html>
<html>
<head>
    <title>Home | Lagu Anda</title>
        <style>
        body {
            background-image: url(https://www.shutterstock.com/shutterstock/videos/1059635129/thumb/1.jpg?ip=x480);
            font-family: Arial, sans-serif;
            filter: opacity(96%);
        }

        h1 {
            width: 50%;
            margin: 0 auto;
            padding: 15px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;

            text-align: center;
            color: black;
            font-size: 50px;
        }

        h3 {
            text-align: center;
            font-size: 36px;
            line-height: 1.6;
        }

        h4 {
            text-align: center;
            font-size: 24px;
        }
        .container {
            width: 40%;
            margin: 0 auto;
            padding: 15px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            border: 1px solid;
        }

        a {
            text-align: center;
            font-size: 24px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <header>
        <h1>LAGU HITS</h1>
    </header>

    <br>

    <nav class="container">
            <h3>Tambahkan Lagu Favorit Anda!</h3>
            <h4>Menu</h4>
            <center><button><a href="tambah-lagu.php">Tambah Lagu</a></button></center>
            <br>
            <center><button><a href="list-lagu.php">Daftar Lagu</a></button></center>
    </nav>

    </body>
</html>